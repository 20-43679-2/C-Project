﻿
namespace Hospital_management_system
{
    partial class form_signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_signup));
            this.lbl_information = new System.Windows.Forms.Label();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.lbl_set_pass = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_phn_num = new System.Windows.Forms.TextBox();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.lbl_mail = new System.Windows.Forms.Label();
            this.lbl_gender = new System.Windows.Forms.Label();
            this.btn_submit = new System.Windows.Forms.Button();
            this.lbl_address = new System.Windows.Forms.Label();
            this.lbl_dob = new System.Windows.Forms.Label();
            this.lbl_phn_num = new System.Windows.Forms.Label();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_hospital_management = new System.Windows.Forms.Label();
            this.rbtn_male = new System.Windows.Forms.RadioButton();
            this.rbtn_female = new System.Windows.Forms.RadioButton();
            this.btn_back = new System.Windows.Forms.Button();
            this.dateTimePicker_signup = new System.Windows.Forms.DateTimePicker();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_information
            // 
            this.lbl_information.AutoSize = true;
            this.lbl_information.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_information.Location = new System.Drawing.Point(485, 117);
            this.lbl_information.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_information.Name = "lbl_information";
            this.lbl_information.Size = new System.Drawing.Size(207, 40);
            this.lbl_information.TabIndex = 72;
            this.lbl_information.Text = "Information";
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(402, 691);
            this.txt_password.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_password.Multiline = true;
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(386, 29);
            this.txt_password.TabIndex = 71;
            // 
            // lbl_set_pass
            // 
            this.lbl_set_pass.AutoSize = true;
            this.lbl_set_pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_set_pass.Location = new System.Drawing.Point(190, 691);
            this.lbl_set_pass.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_set_pass.Name = "lbl_set_pass";
            this.lbl_set_pass.Size = new System.Drawing.Size(164, 25);
            this.lbl_set_pass.TabIndex = 70;
            this.lbl_set_pass.Text = "Set Password  :";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(402, 195);
            this.txt_name.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_name.Multiline = true;
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(386, 29);
            this.txt_name.TabIndex = 69;
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(402, 254);
            this.txt_id.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_id.Multiline = true;
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(386, 29);
            this.txt_id.TabIndex = 68;
            // 
            // txt_phn_num
            // 
            this.txt_phn_num.Location = new System.Drawing.Point(402, 329);
            this.txt_phn_num.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_phn_num.Multiline = true;
            this.txt_phn_num.Name = "txt_phn_num";
            this.txt_phn_num.Size = new System.Drawing.Size(386, 29);
            this.txt_phn_num.TabIndex = 67;
            // 
            // txt_address
            // 
            this.txt_address.Location = new System.Drawing.Point(402, 477);
            this.txt_address.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_address.Multiline = true;
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(386, 29);
            this.txt_address.TabIndex = 65;
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(402, 615);
            this.txt_email.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_email.Multiline = true;
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(386, 29);
            this.txt_email.TabIndex = 64;
            // 
            // lbl_mail
            // 
            this.lbl_mail.AutoSize = true;
            this.lbl_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mail.Location = new System.Drawing.Point(268, 615);
            this.lbl_mail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_mail.Name = "lbl_mail";
            this.lbl_mail.Size = new System.Drawing.Size(84, 25);
            this.lbl_mail.TabIndex = 61;
            this.lbl_mail.Text = "Email  :";
            // 
            // lbl_gender
            // 
            this.lbl_gender.AutoSize = true;
            this.lbl_gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gender.Location = new System.Drawing.Point(256, 548);
            this.lbl_gender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_gender.Name = "lbl_gender";
            this.lbl_gender.Size = new System.Drawing.Size(102, 25);
            this.lbl_gender.TabIndex = 60;
            this.lbl_gender.Text = "Gender  :";
            // 
            // btn_submit
            // 
            this.btn_submit.BackColor = System.Drawing.Color.MistyRose;
            this.btn_submit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_submit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_submit.Location = new System.Drawing.Point(483, 837);
            this.btn_submit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(196, 54);
            this.btn_submit.TabIndex = 59;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = false;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address.Location = new System.Drawing.Point(246, 477);
            this.lbl_address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(111, 25);
            this.lbl_address.TabIndex = 58;
            this.lbl_address.Text = "Address  :";
            // 
            // lbl_dob
            // 
            this.lbl_dob.AutoSize = true;
            this.lbl_dob.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dob.Location = new System.Drawing.Point(168, 398);
            this.lbl_dob.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_dob.Name = "lbl_dob";
            this.lbl_dob.Size = new System.Drawing.Size(183, 25);
            this.lbl_dob.TabIndex = 57;
            this.lbl_dob.Text = "Date of birthday  :";
            // 
            // lbl_phn_num
            // 
            this.lbl_phn_num.AutoSize = true;
            this.lbl_phn_num.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_phn_num.Location = new System.Drawing.Point(190, 335);
            this.lbl_phn_num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_phn_num.Name = "lbl_phn_num";
            this.lbl_phn_num.Size = new System.Drawing.Size(165, 25);
            this.lbl_phn_num.TabIndex = 56;
            this.lbl_phn_num.Text = "Phone number :";
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.Location = new System.Drawing.Point(314, 260);
            this.lbl_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(49, 25);
            this.lbl_ID.TabIndex = 55;
            this.lbl_ID.Text = "Id  :";
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(278, 202);
            this.lbl_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(81, 25);
            this.lbl_name.TabIndex = 54;
            this.lbl_name.Text = "Name :";
            // 
            // lbl_hospital_management
            // 
            this.lbl_hospital_management.AutoSize = true;
            this.lbl_hospital_management.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hospital_management.Location = new System.Drawing.Point(298, 25);
            this.lbl_hospital_management.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_hospital_management.Name = "lbl_hospital_management";
            this.lbl_hospital_management.Size = new System.Drawing.Size(592, 64);
            this.lbl_hospital_management.TabIndex = 53;
            this.lbl_hospital_management.Text = "Hospital Management";
            // 
            // rbtn_male
            // 
            this.rbtn_male.AutoSize = true;
            this.rbtn_male.Location = new System.Drawing.Point(402, 548);
            this.rbtn_male.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbtn_male.Name = "rbtn_male";
            this.rbtn_male.Size = new System.Drawing.Size(68, 24);
            this.rbtn_male.TabIndex = 73;
            this.rbtn_male.TabStop = true;
            this.rbtn_male.Text = "Male";
            this.rbtn_male.UseVisualStyleBackColor = true;
            this.rbtn_male.CheckedChanged += new System.EventHandler(this.rbtn_male_CheckedChanged);
            // 
            // rbtn_female
            // 
            this.rbtn_female.AutoSize = true;
            this.rbtn_female.Location = new System.Drawing.Point(670, 548);
            this.rbtn_female.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbtn_female.Name = "rbtn_female";
            this.rbtn_female.Size = new System.Drawing.Size(87, 24);
            this.rbtn_female.TabIndex = 74;
            this.rbtn_female.TabStop = true;
            this.rbtn_female.Text = "Female";
            this.rbtn_female.UseVisualStyleBackColor = true;
            this.rbtn_female.CheckedChanged += new System.EventHandler(this.rbtn_female_CheckedChanged);
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.DodgerBlue;
            this.btn_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_back.Location = new System.Drawing.Point(932, 837);
            this.btn_back.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(98, 45);
            this.btn_back.TabIndex = 76;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // dateTimePicker_signup
            // 
            this.dateTimePicker_signup.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_signup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_signup.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_signup.Location = new System.Drawing.Point(402, 398);
            this.dateTimePicker_signup.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePicker_signup.Name = "dateTimePicker_signup";
            this.dateTimePicker_signup.Size = new System.Drawing.Size(386, 30);
            this.dateTimePicker_signup.TabIndex = 82;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(857, 837);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(47, 45);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 83;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(402, 107);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 84;
            this.pictureBox1.TabStop = false;
            // 
            // form_signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1258, 994);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.dateTimePicker_signup);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.rbtn_female);
            this.Controls.Add(this.rbtn_male);
            this.Controls.Add(this.lbl_information);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.lbl_set_pass);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.txt_id);
            this.Controls.Add(this.txt_phn_num);
            this.Controls.Add(this.txt_address);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.lbl_mail);
            this.Controls.Add(this.lbl_gender);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.lbl_address);
            this.Controls.Add(this.lbl_dob);
            this.Controls.Add(this.lbl_phn_num);
            this.Controls.Add(this.lbl_ID);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.lbl_hospital_management);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "form_signup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "signup";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_information;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Label lbl_set_pass;
        private System.Windows.Forms.TextBox txt_phn_num;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Label lbl_mail;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.Button btn_submit;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label lbl_dob;
        private System.Windows.Forms.Label lbl_phn_num;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_hospital_management;
        private System.Windows.Forms.RadioButton rbtn_male;
        private System.Windows.Forms.RadioButton rbtn_female;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.DateTimePicker dateTimePicker_signup;
        public System.Windows.Forms.TextBox txt_name;
        public System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}